<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_All Categories        Alexa Skills  _59be89</name>
   <tag></tag>
   <elementGuidId>8f39884d-8645-430e-9318-4e3c57c4854a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#searchDropdownBox</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='searchDropdownBox']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>16931b3a-2853-47d2-ae11-4f6494a8b70d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>searchDropdownDescription</value>
      <webElementGuid>37eb603b-f7cb-404f-97a1-df6405977203</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown</value>
      <webElementGuid>916b2d72-7c03-41ad-8b30-c63c20d17c57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-digest</name>
      <type>Main</type>
      <value>tMtXT79+70L/E2safYLVSgvzHcs=</value>
      <webElementGuid>d32e0bcc-cb25-4196-90a2-f4f34295a87d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-selected</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>fe04e44f-c212-439e-b26d-90a67cba407d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>searchDropdownBox</value>
      <webElementGuid>b4b3faa7-a9db-48b0-a8bc-8072e112c0ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>url</value>
      <webElementGuid>268ef14d-3dbd-4914-92ab-72bf776f8640</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>c442f8d6-8f94-47a6-9cb3-a35eb8149238</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Search in</value>
      <webElementGuid>2ee2e6b5-2a6a-413f-924a-093cfa24caca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Deals
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    </value>
      <webElementGuid>9a50a7e2-fc11-4ea0-ab7d-4d6efbc1602b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;searchDropdownBox&quot;)</value>
      <webElementGuid>19b731f5-e27f-4307-9ffd-a46a9a7b874d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='searchDropdownBox']</value>
      <webElementGuid>6784deb1-3dcb-4344-9e7e-8cee9329c7c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div/select</value>
      <webElementGuid>a75507d7-782c-4897-bbb5-6e49a119bc95</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>7771e633-05ff-44fc-876d-f091b94cd690</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'searchDropdownBox' and @name = 'url' and @title = 'Search in' and (text() = '
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Deals
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    ' or . = '
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Deals
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    ')]</value>
      <webElementGuid>355573f9-221a-4334-95cf-dbc00f5287aa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

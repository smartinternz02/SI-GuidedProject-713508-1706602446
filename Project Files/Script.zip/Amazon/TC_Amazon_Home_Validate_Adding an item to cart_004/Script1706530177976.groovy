import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.amazon.in/')

WebUI.click(findTestObject('Object Repository/Amazon_Pages_adding an item to cart_OR/Page_Online Shopping site in India Shop Onl_10c5f3/span_Hello, sign in'))

WebUI.setText(findTestObject('Object Repository/Amazon_Pages_adding an item to cart_OR/Page_Amazon Sign In/input_email'), 
    '7070351882')

WebUI.click(findTestObject('Object Repository/Amazon_Pages_adding an item to cart_OR/Page_Amazon Sign In/inputcontinue'))

WebUI.setEncryptedText(findTestObject('Object Repository/Amazon_Pages_adding an item to cart_OR/Page_Amazon Sign In/input_password'), 
    'bcj1Feu6SE33E1oat+Xrzg==')

WebUI.click(findTestObject('Object Repository/Amazon_Pages_adding an item to cart_OR/Page_Amazon Sign In/inputsignInSubmit'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Amazon_Pages_adding an item to cart_OR/Page_Online Shopping site in India Shop Onl_10c5f3/select_All Categories        Alexa Skills  _59be89'), 
    'search-alias=electronics', true)

WebUI.setText(findTestObject('Object Repository/Amazon_Pages_adding an item to cart_OR/Page_Online Shopping site in India Shop Onl_10c5f3/input_field-keywords'), 
    'laptops')

WebUI.click(findTestObject('Object Repository/Amazon_Pages_adding an item to cart_OR/Page_Online Shopping site in India Shop Onl_10c5f3/inputnav-search-submit-button'))

WebUI.click(findTestObject('Object Repository/Amazon_Pages_adding an item to cart_OR/Page_Amazon.in  laptops/span_14 Laptop, 12th Gen Intel Core i3-1215_03b7e4'))

WebUI.switchToWindowTitle('Dell 14 Laptop, 12th Gen Intel Core i3-1215U Processor/8GB/512GB SSD/Intel UHD Graphics/14.0"(35.56cm) FHD/Windows 11 + MSO\'21/15 Month McAfee/Spill-Resistant Keyboard/Grey/Thin & Light 1.48kg : Amazon.in: Electronics')

WebUI.click(findTestObject('Object Repository/Amazon_Pages_adding an item to cart_OR/Page_Dell 14 Laptop, 12th Gen Intel Core i3_dbc8bb/input_submit.add-to-cart'))

WebUI.closeBrowser()

